# Exam proctoring > 2024-11-23 11:06am
https://universe.roboflow.com/rando-z51vm/exam-proctoring-zewbp

Provided by a Roboflow user
License: CC BY 4.0

