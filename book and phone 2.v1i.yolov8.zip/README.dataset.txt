# book and phone 2 > 2024-07-19 12:56am
https://universe.roboflow.com/data-jcskl/book-and-phone-2

Provided by a Roboflow user
License: CC BY 4.0

